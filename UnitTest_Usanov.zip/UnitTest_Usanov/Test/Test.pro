QT += testlib network sql
QT -= gui

CONFIG += qt console warn_on depend_includepath testcase
CONFIG -= app_bundle

TEMPLATE = app

SOURCES +=  tst_test.cpp \
            "C:\Users\WvLad1ck\Desktop\Server_client\Server_client\Server 2\serverfunction.cpp" \
            "C:\Users\WvLad1ck\Desktop\Server_client\Server_client\Server 2\mytcpserver.cpp" \
            "C:\Users\WvLad1ck\Desktop\Server_client\Server_client\Server 2\database.cpp"

HEADERS +=  "C:\Users\WvLad1ck\Desktop\Server_client\Server_client\Server 2\database.h" \
            "C:\Users\WvLad1ck\Desktop\Server_client\Server_client\Server 2\serverfunction.h" \
            "C:\Users\WvLad1ck\Desktop\Server_client\Server_client\Server 2\mytcpserver.h"
