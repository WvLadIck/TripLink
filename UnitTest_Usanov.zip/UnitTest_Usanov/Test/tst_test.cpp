#include <QtTest>
#include "C:\Users\WvLad1ck\Desktop\Server_client\Server_client\Server 2\serverfunction.h" // Укажите правильный путь к вашему файлу

class ServerFunctionTest : public QObject {
    Q_OBJECT

public:
    ServerFunctionTest();
    ~ServerFunctionTest();

private slots:
    void test_isValidEmail_valid();
    void test_isValidEmail_invalid();
};

ServerFunctionTest::ServerFunctionTest() {
}

ServerFunctionTest::~ServerFunctionTest() {
}

void ServerFunctionTest::test_isValidEmail_valid() {
    // Проверка валидных email-адресов
    QVERIFY2(ServerFunction::isValidEmail("test@mail.ru") == true, "test@example.com should be valid");
}

void ServerFunctionTest::test_isValidEmail_invalid() {
    // Проверка невалидных email-адресов
    QVERIFY2(ServerFunction::isValidEmail("#") == false, "test should be invalid");

}

QTEST_APPLESS_MAIN(ServerFunctionTest)

#include "tst_test.moc"
