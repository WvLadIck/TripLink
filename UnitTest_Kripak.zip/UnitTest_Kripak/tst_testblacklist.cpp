#include <QtTest>
#include <QTcpSocket>
#include <QCoreApplication>
#include <QSqlQuery>
#include "/home/xsenia/TripLink/Server/mytcpserver.h"
#include "/home/xsenia/TripLink/Server/serverfunction.h"
#include "/home/xsenia/TripLink/Server/database.h"

// Три теста должны проходить, один выдавать ошибку так как мы пытаемся добавить пользователя с 3мя параметрами (а бд требует 4х параметров)


class TestBlacklist : public QObject
{
    Q_OBJECT

private slots:
    void initTestCase();
    void cleanupTestCase();
    void testGetBlacklist();
    void testAddUserWithThreeParams();

private:
    Database* db;
    QString userA, userB;
};

void TestBlacklist::initTestCase()
{
    db = &Database::getInstance();

    QSqlQuery query;
    query.exec("DROP TABLE IF EXISTS users;");
    query.exec("DROP TABLE IF EXISTS blacklist;");

    // Теперь вызываем createTable() для создания новых таблиц
    QVERIFY(db->createTable());

    userA = "test_userA_" + QString::number(QDateTime::currentSecsSinceEpoch());
    userB = "test_userB_" + QString::number(QDateTime::currentSecsSinceEpoch());


    QString dummyPass = "12345";
    QString dummyEmailA = "a_" + QString::number(QDateTime::currentSecsSinceEpoch()) + "@mail.com";
    QString dummyEmailB = "b_" + QString::number(QDateTime::currentSecsSinceEpoch()) + "@mail.com";

    QString dummyNameA = "Test User A";
    QString dummyNameB = "Test User B";

    QVERIFY(db->addUser({userA, dummyPass, dummyEmailA, dummyNameA}));
    QVERIFY(db->addUser({userB, dummyPass, dummyEmailB, dummyNameB}));

    // Добавим userB в черный список userA
    query.prepare("INSERT INTO blacklist (user_id, blocked_user_id) "
                  "VALUES ((SELECT id FROM users WHERE login = :userA), "
                  "(SELECT id FROM users WHERE login = :userB))");
    query.bindValue(":userA", userA);
    query.bindValue(":userB", userB);
    QVERIFY2(query.exec(), qPrintable("Failed to insert into blacklist: " + query.lastError().text()));
}

void TestBlacklist::cleanupTestCase()
{
    QSqlQuery query;

    query.prepare("DELETE FROM blacklist "
                  "WHERE user_id = (SELECT id FROM users WHERE login = :userA) "
                  "   OR blocked_user_id = (SELECT id FROM users WHERE login = :userB)");
    query.bindValue(":userA", userA);
    query.bindValue(":userB", userB);
    query.exec();

    query.prepare("DELETE FROM users WHERE login IN (:userA, :userB)");
    query.bindValue(":userA", userA);
    query.bindValue(":userB", userB);
    query.exec();
}

void TestBlacklist::testGetBlacklist()
{
    QVector<QString> blacklist = db->getBlacklist(userA);

    QVERIFY(blacklist.contains(userB));
    QCOMPARE(blacklist.size(), 1);  // Предполагаем, что в черном списке только один пользователь
}

void TestBlacklist::testAddUserWithThreeParams()
{
    QString userA = "test_userA_" + QString::number(QDateTime::currentSecsSinceEpoch());
    QString dummyPass = "12345";
    QString dummyEmail = "a_" + QString::number(QDateTime::currentSecsSinceEpoch()) + "@mail.com";

    // Передаем только 3 параметра вместо 4
    bool result = db->addUser({userA, dummyPass, dummyEmail});

    // Тест должен не пройти, если метод возвращает false (то есть ошибка)
    QVERIFY2(result, "addUser should fail with 3 parameters");

    // Проверка, что пользователь не добавился в базу
    QSqlQuery query;
    query.prepare("SELECT id FROM users WHERE login = :login");
    query.bindValue(":login", userA);
    query.exec();

    // Убедимся, что пользователя не добавили в базу
    QVERIFY2(query.size() == 0, "User should not have been added to the database with 3 parameters.");
}



QTEST_GUILESS_MAIN(TestBlacklist)
#include "tst_testblacklist.moc"
