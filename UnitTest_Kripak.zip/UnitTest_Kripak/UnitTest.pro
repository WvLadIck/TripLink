QT += testlib
QT += sql
QT += network
QT += widgets
QT -= gui

CONFIG += qt console warn_on depend_includepath testcase
CONFIG -= app_bundle

TEMPLATE = app

SOURCES +=  \
       /home/xsenia/TripLink/Server/database.cpp \
       /home/xsenia/TripLink/Server/serverfunction.cpp \
       /home/xsenia/TripLink/Server/mytcpserver.cpp \
       tst_testblacklist.cpp


HEADERS += /home/xsenia/TripLink/Server/database.h \
           /home/xsenia/TripLink/Server/serverfunction.h \
           /home/xsenia/TripLink/Server/mytcpserver.h

macx {
    QMAKE_MACOSX_DEPLOYMENT_TARGET = 10.15
}


CONFIG += testlib c++11
TARGET = UnitTest
DESTDIR = $$OUT_PWD
