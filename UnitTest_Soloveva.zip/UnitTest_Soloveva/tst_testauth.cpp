#include <QtTest>
#include <QTcpSocket>
#include <QCoreApplication>
#include <QSqlQuery>
#include "/Users/anastasiasoloveva/Desktop/Server2/mytcpserver.h"
#include "/Users/anastasiasoloveva/Desktop/Server2/serverfunction.h"
#include "/Users/anastasiasoloveva/Desktop/Server2/database.h"

class TestAuth : public QObject
{
    Q_OBJECT

public:
    TestAuth();
    ~TestAuth();

private slots:
    void initTestCase();
    void cleanupTestCase();
    void testSuccessfulAuth();
    void testFailedAuth();
    void testInvalidFormat();

private:
    QTcpSocket* testSocket;
    Database* db;
    QCoreApplication* app;
    QString testUser = "testuser_" + QString::number(QDateTime::currentSecsSinceEpoch());
    QString testPass = "testpass";
    QString testEmail = "test_" + QString::number(QDateTime::currentSecsSinceEpoch()) + "@example.com";
};

TestAuth::TestAuth() {
    int argc = 0;
    char** argv = nullptr;
    app = new QCoreApplication(argc, argv);

    testSocket = new QTcpSocket(this);
    testSocket->connectToHost("localhost", 6000);
    if (!testSocket->waitForConnected(1000)) {
        QFAIL("Failed to connect to server");
    }

    // Считываем приветственное сообщение
    if (!testSocket->waitForReadyRead(1000)) {
        QFAIL("Не удалось прочитать приветственное сообщение от сервера!");
    }
    testSocket->readAll(); // Игнорируем приветственное сообщение
}

TestAuth::~TestAuth() {
    testSocket->disconnectFromHost();
    if (testSocket->state() != QAbstractSocket::UnconnectedState) {
        testSocket->waitForDisconnected();
    }
    delete testSocket;
    delete app;
}

void TestAuth::initTestCase()
{
    // Если QCoreApplication еще не создан, создаем его
    if (!QCoreApplication::instance()) {
        static int argc = 1;
        static char* argv[] = { (char*)"test" };
        static QCoreApplication app(argc, argv);
    }
    db = &Database::getInstance();
    if (!db->createTable()) {
        QFAIL("Failed to create database table");
    }
    // Удаляем старые тестовые данные, если они есть
    QSqlQuery query;
    query.exec("DELETE FROM users WHERE login LIKE 'testuser_%'");
    // Создаем уникального тестового пользователя
    QStringList userData = {testUser, testPass, testEmail};
    if (!db->addUser(userData)) {
        QFAIL("Failed to add test user");
    }
}

void TestAuth::cleanupTestCase()
{
    testSocket->disconnectFromHost();
    if (testSocket->state() != QAbstractSocket::UnconnectedState) {
        testSocket->waitForDisconnected();
    }

    // Удаляем тестового пользователя
    QSqlQuery query;
    query.prepare("DELETE FROM users WHERE login = ?");
    query.addBindValue(testUser);
    query.exec();
}



    void TestAuth::testSuccessfulAuth()
{
    qDebug() << "Test User:" << testUser;
    qDebug() << "Test Pass:" << testPass;

    // Порядок аргументов исправлен
    QByteArray message = QString("auth&%1&%2\r\n").arg(testUser).arg(testPass).toUtf8();
    testSocket->write(message);

    // Увеличиваем время ожидания и добавляем цикл чтения
    QByteArray response;
    if (!testSocket->waitForReadyRead(5000)) {
        QFAIL("No response from server");
    }

    // Читаем все доступные данные
    while (testSocket->bytesAvailable() > 0) {
        response += testSocket->readAll();
        if (!testSocket->waitForReadyRead(100)) {
            break;
        }
    }

    QString responseStr = QString::fromUtf8(response).trimmed();
    qDebug() << "Full Server Response:" << responseStr;

    QString firstLine = responseStr.split('\n').first().trimmed();

    if (!firstLine.startsWith("auth+")) {
        QFAIL(qPrintable(QString("Authentication failed. Expected 'auth+', got '%1'").arg(firstLine)));
    }

    QVERIFY2(firstLine.contains(testUser),
             qPrintable(QString("Response should contain username. Actual response: '%1'").arg(firstLine)));
}

void TestAuth::testFailedAuth()
{
    QByteArray message = QString("auth&%1&wrongpass\r\n").arg(testUser).toUtf8();
    testSocket->write(message);

    // Увеличиваем время ожидания
    if (!testSocket->waitForReadyRead(5000)) {
        QFAIL("No response from server");
    }


    QByteArray response = testSocket->readAll();
    QString responseStr = QString::fromUtf8(response).trimmed();
    // Разделяем ответ по строкам и берем первую
    QString firstLine = responseStr.split('\n').first().trimmed();

    QCOMPARE(firstLine, QString("auth-"));
}
void TestAuth::testInvalidFormat()
{
    QByteArray message = QString("auth&%1\r\n").arg(testUser).toUtf8();
    testSocket->write(message);

    // Увеличиваем время ожидания
    if (!testSocket->waitForReadyRead(5000)) {
        QFAIL("No response from server");
    }

    QByteArray response = testSocket->readAll();
    QString responseStr = QString::fromUtf8(response).trimmed();
    // Разделяем ответ по строкам и берем первую
    QString firstLine = responseStr.split('\n').first().trimmed();

    QCOMPARE(firstLine, QString("auth-"));
}

QTEST_GUILESS_MAIN(TestAuth)
#include "tst_testauth.moc"
