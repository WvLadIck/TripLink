QT += testlib
QT += sql
QT += network
QT += widgets
QT -= gui

CONFIG += qt console warn_on depend_includepath testcase
CONFIG -= app_bundle

TEMPLATE = app

SOURCES +=  tst_testauth.cpp \
       /Users/anastasiasoloveva/Desktop/Server2/database.cpp \
       /Users/anastasiasoloveva/Desktop/Server2/serverfunction.cpp \
       /Users/anastasiasoloveva/Desktop/Server2/mytcpserver.cpp


HEADERS += /Users/anastasiasoloveva/Desktop/Server2/database.h \
           /Users/anastasiasoloveva/Desktop/Server2/serverfunction.h \
           /Users/anastasiasoloveva/Desktop/Server2/mytcpserver.h

macx {
    QMAKE_MACOSX_DEPLOYMENT_TARGET = 10.15
}


CONFIG += qtestlib c++11
TARGET = UnitTest
DESTDIR = $$OUT_PWD
